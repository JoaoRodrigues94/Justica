var conexao = require('../../config/conexao.js');

module.exports = {
    getAllAdv,
    advogadosEdit,
    newAdvogado,
    advogadosGetById
}

function getAllAdv (callback){
    conexao.query('SELECT * FROM dados212n.`advogado -adv`', callback);
}

function advogadosGetById (id, callback){
    conexao.query('select * from dados212n.`advogado -adv` where adv_codigo = ' + id, callback);
}

function advogadosEdit(dados, callback){
    var sql = "UPDATE dados212n.`advogado -adv` SET adv_nome = '" + dados.adv_nome + 
    "' , adv_apelido = '" + dados.adv_apelido + 
    "' , adv_sexo = '" + dados.adv_sexo + 
    "' , adv_faculdade = '" + dados.adv_faculdade + 
    "' , adv_dtformatura = '" + dados.adv_dtformatura + 
    "'  WHERE adv_codigo = " + dados.adv_codigo;

    conexao.query(sql, callback);
}

function newAdvogado(dados, callback) {

    var msql = "INSERT INTO dados212n.`advogado -adv` SET ?"

	conexao.query(msql, dados, callback);
}