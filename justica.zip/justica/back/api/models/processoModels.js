var conexao = require('../../config/conexao.js');

module.exports = {
    getAllProcessos,
    processosEditar,
    processosGetById,
    processosNovo
}

function getAllProcessos (callback){
    conexao.query('select * from dados212n.`processo - pro`', callback);
}

function processosGetById (id, callback){
    conexao.query('select * from dados212n.`processo - pro` where pro_codigo = ' + id, callback);
}

function processosEditar(dados, callback) {
    var msql = "UPDATE dados212n.`processo - pro` SET ?"

    console.log(msql);
    
    conexao.query(msql, dados, callback);
}

function processosNovo(dados, callback) {
    var msql = 'INSERT INTO dados212n.`processo - pro` SET ? ';

	conexao.query(msql, dados, callback);
}
