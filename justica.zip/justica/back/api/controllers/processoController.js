const processoModels = require('../models/processoModels.js');

module.exports = {
    processoMenu,
    processoGetAll,
    processosGetById,
    processosNovo,
    processosEditar
}

function processoMenu(req, res){
    res.json('Rota Processos Encontrada!');
    console.log('Rota Processos Encontrada!');
}

function processoGetAll(req, res){
   console.log('Listar Processos {M O D E L}');
   processoModels.getAllProcessos( function(err, resposta){
        console.log('Retorno de Processos { M O D E L}\n', resposta)
        if(err){
            throw err;
        }else {
            res.json(resposta)
        }
    })
}

function processosGetById(req, res){
   const id = req.params.codigo;
   console.log(`Parametro esperado: ` + id)
   processoModels.processosGetById(id, function(err, resposta){
        console.log('Retorno de Processos { M O D E L}\n', resposta)
        if(err){
            throw err;
        }else {
            res.json(resposta)
        }
    })
}

function processosNovo(req, res) {
    var dados = req.body;
    dados.pro_codigo = null;
    console.log("Controller: " + dados.pro_codigo);
    processoModels.processosNovo(dados, function (err, result) {
        if (err) {
            throw err;
        }
        res.redirect('/processos');
    })
}


function processosEditar(req, res) {
    var dados = req.body;

    processoModels.processosEditar(dados, function (err, result) {
        if (err) {
            throw err;
        }
        res.redirect('/processos');
    });
}

