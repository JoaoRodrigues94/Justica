module.exports = {
    indexControllers,
}

function indexControllers(req, res){
    res.json('Rota Raiz Encontrada!');
    console.log('Rota Raiz Encontrada!');
}