const advModels = require('../models/advModels.js');

module.exports = {
    advMenu,
    advGetAll,
    advogadosGetById,
    advogadosEdit,
    newAdvogado
}

function advMenu(req, res){
    res.json('Rota advogados Encontrada!');
    console.log('Rota Advogados Encontrada!');
}

function advGetAll(req, res){
    console.log('Listar Advogados {M O D E L}');
    advModels.getAllAdv( function(err, resposta){
         console.log('Retorno de Advogados { M O D E L}\n', resposta)
         if(err){
             throw err;
         }else {
             res.json(resposta)
         }
     })
 }

 function advogadosGetById(req, res){
    const id = req.params.codigo;
    advModels.advogadosGetById(id, function(err, resposta){
         if(err){
             throw err;
         }else {
             res.json(resposta)
         }
     })
 }

 function advogadosEdit(req, res) {
    var dados = req.body;

    advModels.advogadosEdit(dados, function (err, result) {
        if (err) {
            throw err;
        }
        res.redirect('/advogados');
    });
}

function newAdvogado(req, res) {
    var dados = req.body;
    advModels.newAdvogado(dados, function (err, result) {
        if (err) {
            throw err;
        }
        res.redirect('/advogados');
    })
}