const controllerProcessos = require('../controllers/processoController.js');

server.get('/processos', controllerProcessos.processoGetAll);

server.get('/processos/:codigo', controllerProcessos.processosGetById);

server.put('/processo/:codigo', controllerProcessos.processosEditar)

server.post('/processos', controllerProcessos.processosNovo)