const controllerAdv = require('../controllers/advogadosControllers.js');
server.get('/advogado', controllerAdv.advMenu);

server.get('/advogados', controllerAdv.advGetAll);

server.get('/advogados/:id', controllerAdv.advGetAll);

server.put('/advogados/:codigo', controllerAdv.advogadosGetById);
server.put('/advogado/:codigo', controllerAdv.advogadosEdit);

server.post('/advogados', controllerAdv.newAdvogado);