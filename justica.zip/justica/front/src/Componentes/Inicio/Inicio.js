import React from "react"
import '../../Styles/Styles.css';

function Inicio() {
  return (
        <div id="home">
            <h2 className='welcome'> Bem Vindo </h2>
        </div>
  );
}

export default Inicio;