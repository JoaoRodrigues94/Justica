import React from 'react';
import ContainerGeral from '../ContainerGeral/ContainerGeral.js';
import './App.css';

function App() {
  return (
    <div>
      <ContainerGeral/>
    </div>
  );
}

export default App;