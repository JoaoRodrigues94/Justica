import '../../Styles/Styles.css';

export default function Rodape() {
  return (
    <div className = "rodape">
        <h3 style={{ textAlign: 'center' }}>Projeto Desenvolvido Por: João Paulo Fernandes Rodrigues</h3>
    </div>
  );
}

